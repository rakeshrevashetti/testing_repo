# Terraform WorkSpace

## Terraform workspaces are a powerful feature that allows you to manage multiple states for a single configuration. They are particularly useful for managing different environments like development, staging, and production within the same Terraform configuration.

Here’s a comprehensive guide to the main Terraform workspace commands:

### 1. **Create a New Workspace**
   - **Command:** `terraform workspace new <workspace_name>`
   - **Description:** This command creates a new workspace with the specified name. If the workspace already exists, Terraform will not create a new one and will raise an error.
   - **Example:** `terraform workspace new dev`

### 2. **List All Workspaces**
   - **Command:** `terraform workspace list`
   - **Description:** Lists all available workspaces. The currently selected workspace will be highlighted with an asterisk (*).
   - **Example Output:**
     ``` hcl
       default
     * dev
       staging
     ```

``` hcl
├── Readme.md
├── main.tf
├── modules
│   └── ec2_instance
│       └── main.tf
├── terraform.tfstate.d
│   └── dev
│       └── terraform.tfstate
└── terraform.tfvars
```

### 3. **Select a Workspace**
   - **Command:** `terraform workspace select <workspace_name>`
   - **Description:** Switches to the specified workspace. If the workspace does not exist, Terraform will return an error.
   - **Example:** `terraform workspace select staging`

### 4. **Show Current Workspace**
   - **Command:** `terraform workspace show`
   - **Description:** Displays the name of the current workspace.
   - **Example Output:** `dev`

### 5. **Delete a Workspace**
   - **Command:** `terraform workspace delete <workspace_name>`
   - **Description:** Deletes the specified workspace. You cannot delete the currently active workspace, so you must first switch to a different workspace before deleting the current one.
   - **Example:** `terraform workspace delete dev`

### 6. **Get Workspace Information (Advanced)**
   - **Command:** `terraform workspace info`
   - **Description:** This command gives more detailed information about the current workspace, such as its name and the directory where its state files are stored.
   - **Example Output:**
     ``` hcl
     Workspace: dev
     State: dev/terraform.tfstate
     ```


### 7. **Show Detailed Resource Information in a Workspace**
   - **Command:** `terraform state show <resource_name>`
   - **Description:** This command shows detailed information about a specific resource in the current workspace.
   - **Example:** `terraform state show aws_instance.example`

### 8. Notes on Usage:
- **Workspace Naming:** Names are case-sensitive and cannot contain spaces or special characters.
- **Default Workspace:** The `default` workspace is the initial workspace. It cannot be deleted but can be used to manage resources like any other workspace.
- **State Management:** Each workspace has its own state file. Operations like `terraform plan` and `terraform apply` are executed against the state of the currently selected workspace.
- **Common Workflow:**
